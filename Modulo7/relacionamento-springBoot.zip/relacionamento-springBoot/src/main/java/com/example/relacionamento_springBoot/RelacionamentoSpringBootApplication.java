package com.example.relacionamento_springBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RelacionamentoSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RelacionamentoSpringBootApplication.class, args);
	}

}
