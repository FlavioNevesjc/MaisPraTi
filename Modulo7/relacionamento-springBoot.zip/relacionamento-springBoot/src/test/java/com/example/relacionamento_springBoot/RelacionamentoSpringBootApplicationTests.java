package com.example.relacionamento_springBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelacionamentoSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
