package com.example.JWT_OAuth2Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtOAuth2DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
