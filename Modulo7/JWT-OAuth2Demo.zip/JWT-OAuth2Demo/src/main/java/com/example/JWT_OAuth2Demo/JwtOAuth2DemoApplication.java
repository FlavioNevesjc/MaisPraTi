package com.example.JWT_OAuth2Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtOAuth2DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtOAuth2DemoApplication.class, args);
	}

}
