package com.flavio.atrividade15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atrividade15Application {

	public static void main(String[] args) {
		SpringApplication.run(Atrividade15Application.class, args);
	}

}
