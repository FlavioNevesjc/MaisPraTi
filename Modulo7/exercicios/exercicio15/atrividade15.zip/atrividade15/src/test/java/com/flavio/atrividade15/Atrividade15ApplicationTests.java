package com.flavio.atrividade15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atrividade15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
